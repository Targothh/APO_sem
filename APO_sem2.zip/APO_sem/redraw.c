// #include "redraw.h"
// #include "objects.h"
// #include "knob_handler.h"


void redraw(GameField *field){
    clear_player(field, 1);
    clear_player(field, 2);
    clear_ball(field);

    handle_knobs(field);

    draw_player(field, 1);
    draw_player(field, 2);
    draw_ball(field);
}