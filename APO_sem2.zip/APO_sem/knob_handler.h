// void handle_direction(int diff, GameField *field, int player);

// void handle_knobs(GameField *field, unsigned char *spiled_base);


uint32_t check_red_knob(GameField *field, unsigned char *spiled_base, uint32_t red_curr);

uint32_t check_blue_knob(GameField *field, unsigned char *spiled_base, uint32_t blue_curr);

