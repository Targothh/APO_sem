
void redraw(GameField *field);