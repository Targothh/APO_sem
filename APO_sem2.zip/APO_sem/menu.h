typedef struct menu{
    int width;          // Šířka displeje
    int height;         // Výška displeje
    unsigned char *parlcd_mem_base; // Adresa řídicího registru
} menu;
